package com.example.kasistore

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class cart : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart2)
    }
}