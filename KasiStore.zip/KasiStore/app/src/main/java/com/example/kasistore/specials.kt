package com.example.kasistore

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class specials : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_specials)
    }
}